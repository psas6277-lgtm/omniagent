OmniAgent — настоящее Android-приложение: твой OmniNode + ИИ-агент.
1) Открой проект в AndroidIDE (Open project). Подожди Gradle sync.
2) Build -> Run (или Build APK), установи APK.
3) В приложении: Агент -> Автопилот -> включи «Доступ к экрану» и «Поверх приложений».
