package com.omninode.app
import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AgentService : AccessibilityService() {
    companion object { var inst: AgentService? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: android.content.Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun nodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        walk(rootInActiveWindow); return out
    }
    private fun label(n: AccessibilityNodeInfo) = (n.text ?: n.contentDescription ?: "").toString()
    fun tapText(t: String): Boolean {
        val q = t.lowercase()
        for (n in nodes()) {
            if (label(n).lowercase().contains(q)) {
                var c: AccessibilityNodeInfo? = n
                while (c != null && !c.isClickable) c = c.parent
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
        }
        return false
    }
    fun typeText(t: String): Boolean {
        val all = nodes()
        val f = all.firstOrNull { it.isEditable && it.isFocused } ?: all.firstOrNull { it.isEditable } ?: return false
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
    fun scroll(down: Boolean): Boolean {
        val n = nodes().firstOrNull { it.isScrollable } ?: return false
        return n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }
    fun screenText(): String = nodes().mapNotNull {
        val s = label(it); if (s.isBlank()) null else if (it.isClickable) "[$s]" else s
    }.distinct().take(120).joinToString(" | ")
}
