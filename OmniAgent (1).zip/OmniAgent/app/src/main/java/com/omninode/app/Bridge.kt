package com.omninode.app
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface

class Bridge(private val c: Context) {
    private val h = Handler(Looper.getMainLooper())
    private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) }
    private fun pkgByName(name: String): String? {
        val pm = c.packageManager; val q = name.lowercase().trim()
        return pm.getInstalledApplications(0).firstOrNull {
            pm.getLaunchIntentForPackage(it.packageName) != null && pm.getApplicationLabel(it).toString().lowercase().contains(q)
        }?.packageName
    }
    @JavascriptInterface fun isNative() = true
    @JavascriptInterface fun hasAccess() = AgentService.inst != null
    @JavascriptInterface fun hasOverlay() = Settings.canDrawOverlays(c)
    @JavascriptInterface fun openAccessSettings() { go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    @JavascriptInterface fun openOverlaySettings() { go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))) }
    @JavascriptInterface fun startOverlay(): Boolean {
        if (!Settings.canDrawOverlays(c)) { openOverlaySettings(); return false }
        c.startForegroundService(Intent(c, OverlayService::class.java)); return true
    }
    @JavascriptInterface fun stopOverlay() { c.stopService(Intent(c, OverlayService::class.java)) }
    @JavascriptInterface fun openApp(name: String): Boolean {
        val p = pkgByName(name) ?: return false
        val i = c.packageManager.getLaunchIntentForPackage(p) ?: return false
        go(i); return true
    }
    @JavascriptInterface fun closeApp(name: String): Boolean {
        val p = pkgByName(name) ?: return false
        go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p")))
        h.postDelayed({ val a = AgentService.inst
            if (a != null) { if (!(a.tapText("Остановить") || a.tapText("Force stop") || a.tapText("Принудительно")))  {} }
        }, 1400)
        h.postDelayed({ val a = AgentService.inst; if (a != null) { a.tapText("ОК") || a.tapText("OK") || a.tapText("Остановить") } }, 2400)
        h.postDelayed({ AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) }, 3200)
        return true
    }
    @JavascriptInterface fun tapText(t: String) = AgentService.inst?.tapText(t) ?: false
    @JavascriptInterface fun typeText(t: String) = AgentService.inst?.typeText(t) ?: false
    @JavascriptInterface fun scroll(down: Boolean) = AgentService.inst?.scroll(down) ?: false
    @JavascriptInterface fun screenText() = AgentService.inst?.screenText() ?: ""
    @JavascriptInterface fun back() = AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
    @JavascriptInterface fun home() = AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
    @JavascriptInterface fun recents() = AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false
    @JavascriptInterface fun openUrl(u: String) { try { go(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) {} }
}
