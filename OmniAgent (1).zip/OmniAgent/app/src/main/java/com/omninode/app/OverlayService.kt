package com.omninode.app
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var v: TextView? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("omni", "OmniNode", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "omni").setContentTitle("OmniNode работает").setSmallIcon(android.R.drawable.ic_menu_compass).build())
        if (v == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val t = TextView(this); t.text = "Ω"; t.textSize = 22f; t.setTextColor(Color.WHITE); t.gravity = Gravity.CENTER
            t.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC8B5CF6")); setStroke(3, Color.WHITE) }
            val lp = WindowManager.LayoutParams(150, 150, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START; lp.x = 20; lp.y = 400
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            t.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); if (Math.abs(e.rawX - sx) > 12) moved = true; wm?.updateViewLayout(t, lp) }
                    MotionEvent.ACTION_UP -> if (!moved) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                }
                true
            }
            wm?.addView(t, lp); v = t
        }
        return START_STICKY
    }
    override fun onDestroy() { v?.let { wm?.removeView(it) }; v = null; super.onDestroy() }
}
